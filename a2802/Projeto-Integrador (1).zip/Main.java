
import a2802.*;

class Main {

  public static void main(String[] args) {
    PessoaIdade ivo = new PessoaIdade();
    ivo.setNome("IvoMetter");
    ivo.setNascimento(2004);
    System.out.println(ivo.toString());
  }
}